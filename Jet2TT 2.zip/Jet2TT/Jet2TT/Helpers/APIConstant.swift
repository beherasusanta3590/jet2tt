//
//  APIConstant.swift
//  Jet2TT
//
//  Created by Susanta Behera on 18/6/20.
//  Copyright © 2020 Susanta Behera. All rights reserved.
//

import UIKit


enum Config {
    //  Base url here
     static let apiUrl:String = "https://5e99a9b1bc561b0016af3540.mockapi.io/jet2/api/v1/blogs?"
}
